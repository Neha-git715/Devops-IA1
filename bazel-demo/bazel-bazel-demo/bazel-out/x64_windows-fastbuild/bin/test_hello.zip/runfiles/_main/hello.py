

def say():
 return "Hello from Neha's Bazel!"


if __name__ == "__main__":
 print(say())