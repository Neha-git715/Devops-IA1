# test_hello.py


import hello


def test_say():
    assert hello.say() == "Hello from Bazel!"